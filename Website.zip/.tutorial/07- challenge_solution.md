# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=EhZuq48gkpM)
<details> <summary> 👀 Answer </summary>

Check out my solution in [this repl](https://replit.com/@DavidAtReplit/Day-074-Solution?v=1).

</details>

- Join our [100 Days Community](https://replit.com/100-days-help)
- Join our [Discord](https://replit.com/discord)
- Want [live support?](https://replit.com/replit-101)