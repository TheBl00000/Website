# 👉 Day 74 Challenge

Today's challenge is to style up yesterday's code.  

Make it utterly, gorgeously stunning.

Research some other CSS tricks, like boxes and padding and apply them to your code.

That's it. The rest is down to your design preferences.


<details> <summary> 💡 Hints </summary>
  
- The [W3 Schools](https://www.w3schools.com/css/) website is an absolute goldmine for HTML and CSS resources.


</details>